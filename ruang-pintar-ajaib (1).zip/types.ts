
export interface Question {
  id: number;
  question: string;
  image: string;
  options: string[];
  correctAnswer: string;
  category: 'math' | 'science' | 'animals' | 'general';
}

export interface ScrambleQuestion {
  id: number;
  word: string; // The correct word (e.g. "BUKU")
  image: string;
  hint: string;
}

export interface MemoryCard {
  id: number;
  content: string; // Emoji or Image URL
  isFlipped: boolean;
  isMatched: boolean;
}

export interface GameState {
  mode: 'quiz' | 'memory' | 'scramble' | 'story'; 
  screen: 'landing' | 'menu' | 'playing' | 'result';
  score: number;
  currentQuestionIndex: number;
  selectedCategory: string | null;
  questions: Question[];
  // Memory Game State
  memoryCards: MemoryCard[];
  flippedIndices: number[];
  moves: number;
  // Scramble Game State
  scrambleQuestions: ScrambleQuestion[];
  currentScrambleLetters: { id: string, char: string, status: 'pool' | 'placed' }[];
  placedLetters: { id: string, char: string }[]; // Letters in the answer slots
}

export interface HelperResponse {
  text: string;
  emotion: 'happy' | 'thinking' | 'encouraging';
}

export interface UserProgress {
  totalStars: number;
  categoryScores: Record<string, number>; // Stores high score per category
  selectedAvatar?: string;
}
