
import React, { useState, useEffect } from 'react';
import { GlassCard } from './components/GlassCard';
import { Button } from './components/Button';
import { SAMPLE_QUESTIONS, MEMORY_EMOJIS, SCRAMBLE_QUESTIONS, AVATARS } from './constants';
import { Question, GameState, UserProgress, MemoryCard, ScrambleQuestion } from './types';
import { getGeminiHelp, getAvatarStory } from './services/geminiService';
import { 
  playClick, playCorrect, playWrong, playWin, playFlip, playPop, 
  startBGM, stopBGM, toggleMute 
} from './services/audioService';
import { 
  Gamepad2, 
  Cat, 
  Trophy, 
  RotateCcw, 
  Bot, 
  CheckCircle, 
  XCircle,
  Home,
  Star,
  Grid3X3,
  Type,
  Volume2,
  BookOpen,
  Music,
  Music2,
  Sparkles,
  Play
} from 'lucide-react';

// --- Helper Component: Adaptive Image ---
// Handles loading states and errors gracefully to prevent "cut off" looks
const AdaptiveImage = ({ src, alt, className = "" }: { src: string, alt: string, className?: string }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
     // Reset state when src changes
     setIsLoading(true);
     setError(false);
  }, [src]);

  return (
    <div className={`relative overflow-hidden bg-slate-900/50 ${className}`}>
      {/* Loading Skeleton */}
      {isLoading && (
        <div className="absolute inset-0 z-10 flex items-center justify-center bg-slate-800 animate-pulse">
           <Sparkles size={32} className="text-slate-600 animate-spin-slow-rotate" />
        </div>
      )}
      
      {/* Actual Image */}
      {!error ? (
        <img 
          src={src} 
          alt={alt} 
          className={`w-full h-full object-contain transition-all duration-700 ${isLoading ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}
          onLoad={() => setIsLoading(false)}
          onError={() => { setIsLoading(false); setError(true); }}
        />
      ) : (
        // Error Fallback
        <div className="absolute inset-0 flex items-center justify-center text-4xl bg-slate-800">
           🖼️
        </div>
      )}
    </div>
  );
};

const App: React.FC = () => {
  // Game State
  const [gameState, setGameState] = useState<GameState>({
    mode: 'quiz',
    screen: 'landing', // Start at landing page
    score: 0,
    currentQuestionIndex: 0,
    selectedCategory: null,
    questions: [],
    memoryCards: [],
    flippedIndices: [],
    moves: 0,
    scrambleQuestions: [],
    currentScrambleLetters: [],
    placedLetters: []
  });

  // Persistent User Progress
  const [userProgress, setUserProgress] = useState<UserProgress>({
    totalStars: 0,
    categoryScores: {},
    selectedAvatar: AVATARS[0]
  });

  // UI Interaction States
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [isThinking, setIsThinking] = useState(false);
  const [aiHint, setAiHint] = useState<string | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isMusicOn, setIsMusicOn] = useState(true);
  const [storyText, setStoryText] = useState<string | null>(null);

  // Load progress
  useEffect(() => {
    const saved = localStorage.getItem('ruang-pintar-progress');
    if (saved) {
      try {
        setUserProgress(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load progress", e);
      }
    }
  }, []);

  const toggleMusic = () => {
    const newState = !isMusicOn;
    setIsMusicOn(newState);
    toggleMute(!newState);
  };

  const enterApp = () => {
    playClickSound();
    if (isMusicOn) startBGM();
    setGameState(prev => ({ ...prev, screen: 'menu' }));
  };

  const saveProgress = (category: string, score: number) => {
    setUserProgress(prev => {
      const currentHighScore = prev.categoryScores[category] || 0;
      let newScores = prev.categoryScores;
      
      // Only update if score is higher
      if (score > currentHighScore) {
        newScores = { ...prev.categoryScores, [category]: score };
      }

      const totalScore = Object.values(newScores).reduce((a, b) => a + b, 0);
      const totalStars = Math.floor(totalScore / 10);

      const newProgress = {
        ...prev,
        categoryScores: newScores,
        totalStars: totalStars
      };
      
      localStorage.setItem('ruang-pintar-progress', JSON.stringify(newProgress));
      return newProgress;
    });
  };

  const handleAvatarSelect = (avatar: string) => {
    playPop();
    const newProgress = { ...userProgress, selectedAvatar: avatar };
    setUserProgress(newProgress);
    localStorage.setItem('ruang-pintar-progress', JSON.stringify(newProgress));
  };

  const playClickSound = () => {
    playClick();
  };

  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      if (window.speechSynthesis.speaking) {
        window.speechSynthesis.cancel();
      }
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'id-ID';
      utterance.rate = 0.9; // Slightly slower for kids
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    }
  };
  
  // --- Quiz Logic ---
  const startQuiz = (category: string) => {
    playClickSound();
    const questions = [...SAMPLE_QUESTIONS[category]].sort(() => Math.random() - 0.5);
    setGameState({
      ...gameState,
      mode: 'quiz',
      screen: 'playing',
      score: 0,
      currentQuestionIndex: 0,
      selectedCategory: category,
      questions: questions,
      memoryCards: [],
      scrambleQuestions: [],
      currentScrambleLetters: [],
      placedLetters: []
    });
    setAiHint(null);
    setSelectedAnswer(null);
    setIsCorrect(null);
    
    setTimeout(() => {
       speakText(questions[0].question);
    }, 800);
  };

  const handleQuizAnswer = (answer: string) => {
    if (selectedAnswer) return;

    const currentQ = gameState.questions[gameState.currentQuestionIndex];
    const correct = answer === currentQ.correctAnswer;

    setSelectedAnswer(answer);
    setIsCorrect(correct);

    if (correct) {
      playCorrect();
      setGameState(prev => ({ ...prev, score: prev.score + 10 }));
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 2000);
    } else {
      playWrong();
    }

    setTimeout(() => {
      if (gameState.currentQuestionIndex < gameState.questions.length - 1) {
        setGameState(prev => ({ ...prev, currentQuestionIndex: prev.currentQuestionIndex + 1 }));
        setSelectedAnswer(null);
        setIsCorrect(null);
        setAiHint(null);
        setTimeout(() => speakText(gameState.questions[gameState.currentQuestionIndex + 1].question), 500);
      } else {
        finishGame(correct ? gameState.score + 10 : gameState.score);
      }
    }, 1500);
  };

  const handleGetHelp = async () => {
    playClickSound();
    if (isThinking || aiHint) return;
    
    setIsThinking(true);
    
    if (gameState.mode === 'quiz') {
      const currentQ = gameState.questions[gameState.currentQuestionIndex];
      try {
        const hint = await getGeminiHelp(currentQ.question, currentQ.options);
        setAiHint(hint);
        speakText(hint);
      } catch (e) {
        setAiHint("Coba perhatikan gambarnya baik-baik ya!");
      } finally {
        setIsThinking(false);
      }
    } else if (gameState.mode === 'scramble') {
      const hint = gameState.scrambleQuestions[gameState.currentQuestionIndex].hint;
      setAiHint(hint);
      speakText(hint);
      setIsThinking(false);
    }
  };

  // --- Story Mode Logic ---
  const startStoryMode = async () => {
    playClickSound();
    setGameState({
      ...gameState,
      mode: 'story',
      screen: 'playing',
      score: 0,
      currentQuestionIndex: 0,
      selectedCategory: 'story',
      questions: [],
      memoryCards: [],
      scrambleQuestions: [],
    });
    setStoryText(null);
    setIsThinking(true);

    try {
      const story = await getAvatarStory(userProgress.selectedAvatar || "🦁");
      setStoryText(story);
      setIsThinking(false);
      setTimeout(() => speakText(story), 500);
    } catch (e) {
      setStoryText("Maaf, buku ceritanya sedang tertutup. Coba lagi nanti ya!");
      setIsThinking(false);
    }
  };

  // --- Memory Game Logic ---
  const startMemoryGame = () => {
    playClickSound();
    const selectedEmojis = MEMORY_EMOJIS.sort(() => 0.5 - Math.random()).slice(0, 6);
    const cards: MemoryCard[] = [...selectedEmojis, ...selectedEmojis]
      .sort(() => 0.5 - Math.random())
      .map((emoji, index) => ({
        id: index,
        content: emoji,
        isFlipped: false,
        isMatched: false
      }));

    setGameState({
      ...gameState,
      mode: 'memory',
      screen: 'playing',
      score: 0,
      selectedCategory: 'memory',
      memoryCards: cards,
      flippedIndices: [],
      moves: 0,
      scrambleQuestions: [],
      currentScrambleLetters: [],
      placedLetters: []
    });
  };

  const handleCardClick = (index: number) => {
    if (
      gameState.flippedIndices.length >= 2 || 
      gameState.memoryCards[index].isFlipped || 
      gameState.memoryCards[index].isMatched
    ) return;

    playFlip();

    const newCards = [...gameState.memoryCards];
    newCards[index].isFlipped = true;
    const newFlipped = [...gameState.flippedIndices, index];

    setGameState(prev => ({ ...prev, memoryCards: newCards, flippedIndices: newFlipped }));

    if (newFlipped.length === 2) {
      const [firstIdx, secondIdx] = newFlipped;
      setGameState(prev => ({ ...prev, moves: prev.moves + 1 }));

      if (newCards[firstIdx].content === newCards[secondIdx].content) {
        setTimeout(() => {
          playCorrect();
          const matchedCards = [...newCards];
          matchedCards[firstIdx].isMatched = true;
          matchedCards[secondIdx].isMatched = true;
          
          setGameState(prev => {
             const newScore = prev.score + 10;
             const allMatched = matchedCards.every(c => c.isMatched);
             if (allMatched) setTimeout(() => finishGame(newScore), 500);
             return { ...prev, score: newScore, memoryCards: matchedCards, flippedIndices: [] };
          });
        }, 500);
      } else {
        setTimeout(() => {
          playWrong();
          const resetCards = [...newCards];
          resetCards[firstIdx].isFlipped = false;
          resetCards[secondIdx].isFlipped = false;
          setGameState(prev => ({ ...prev, memoryCards: resetCards, flippedIndices: [] }));
        }, 1000);
      }
    }
  };

  // --- Scramble Game Logic ---
  const startScrambleGame = () => {
     playClickSound();
     const questions = [...SCRAMBLE_QUESTIONS].sort(() => Math.random() - 0.5);
     const firstQ = questions[0];
     
     setGameState({
       ...gameState,
       mode: 'scramble',
       screen: 'playing',
       score: 0,
       currentQuestionIndex: 0,
       selectedCategory: 'scramble',
       scrambleQuestions: questions,
       ...prepareScrambleLevel(firstQ),
       questions: [],
       memoryCards: []
     });
     setAiHint(null);
  };

  const prepareScrambleLevel = (q: ScrambleQuestion) => {
     const letters = q.word.split('').map((char, i) => ({
        id: `${char}-${i}`,
        char: char,
        status: 'pool' as const
     })).sort(() => Math.random() - 0.5);

     return {
        currentScrambleLetters: letters,
        placedLetters: Array(q.word.length).fill(null).map(() => ({ id: '', char: '' })) // Empty placeholders
     };
  };

  const handleLetterClick = (letterId: string) => {
    playClickSound();
    const letter = gameState.currentScrambleLetters.find(l => l.id === letterId);
    if (!letter || letter.status === 'placed') return;

    // Find first empty slot
    const emptySlotIndex = gameState.placedLetters.findIndex(l => l.char === '');
    if (emptySlotIndex === -1) return;

    const newPlaced = [...gameState.placedLetters];
    newPlaced[emptySlotIndex] = { id: letter.id, char: letter.char };

    const newPool = gameState.currentScrambleLetters.map(l => 
       l.id === letterId ? { ...l, status: 'placed' as const } : l
    );

    setGameState(prev => ({ ...prev, currentScrambleLetters: newPool, placedLetters: newPlaced }));
    
    // Check if full
    if (emptySlotIndex === gameState.placedLetters.length - 1) {
       checkScrambleAnswer(newPlaced);
    }
  };

  const handleSlotClick = (index: number) => {
    const slot = gameState.placedLetters[index];
    if (slot.char === '') return;
    
    playClickSound();

    const newPlaced = [...gameState.placedLetters];
    newPlaced[index] = { id: '', char: '' };

    const newPool = gameState.currentScrambleLetters.map(l => 
       l.id === slot.id ? { ...l, status: 'pool' as const } : l
    );

    setGameState(prev => ({ ...prev, currentScrambleLetters: newPool, placedLetters: newPlaced }));
  };

  const checkScrambleAnswer = (placed: {char: string}[]) => {
     const currentWord = placed.map(p => p.char).join('');
     const correctWord = gameState.scrambleQuestions[gameState.currentQuestionIndex].word;

     if (currentWord === correctWord) {
        playCorrect();
        setShowConfetti(true);
        setTimeout(() => setShowConfetti(false), 2000);
        
        setTimeout(() => {
           if (gameState.currentQuestionIndex < gameState.scrambleQuestions.length - 1) {
              const nextIndex = gameState.currentQuestionIndex + 1;
              const nextQ = gameState.scrambleQuestions[nextIndex];
              setGameState(prev => ({
                 ...prev,
                 score: prev.score + 10,
                 currentQuestionIndex: nextIndex,
                 ...prepareScrambleLevel(nextQ)
              }));
           } else {
              finishGame(gameState.score + 10);
           }
        }, 1500);
     } else {
        playWrong();
     }
  };

  // --- Common Logic ---
  const finishGame = (finalScore: number) => {
    if (gameState.selectedCategory && gameState.selectedCategory !== 'story') {
      saveProgress(gameState.selectedCategory, finalScore);
    }
    playWin();
    setGameState(prev => ({ ...prev, score: finalScore, screen: 'result' }));
  };

  const resetGame = () => {
    playClickSound();
    window.speechSynthesis.cancel();
    setGameState(prev => ({
       ...prev,
       screen: 'menu',
       score: 0,
       currentQuestionIndex: 0
    }));
  };

  // --- Renderers ---
  const renderStars = (count: number) => (
    <div className="flex gap-1">
      {[...Array(3)].map((_, i) => (
        <Star key={i} size={16} className={`${i < count ? 'fill-yellow-400 text-yellow-400' : 'text-slate-600'}`} />
      ))}
    </div>
  );

  const renderLanding = () => {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4 text-center relative z-20">
        {/* Decorative background elements */}
        <div className="absolute top-[15%] left-[10%] animate-float text-6xl opacity-30 select-none">✨</div>
        <div className="absolute bottom-[20%] right-[10%] animate-float-slow text-6xl opacity-30 select-none">🚀</div>
        
        <GlassCard className="p-8 md:p-10 flex flex-col items-center gap-8 max-w-md w-full animate-float-slow">
          <div className="relative w-full">
             <div className="absolute inset-0 bg-pink-500 blur-3xl opacity-20 rounded-full pointer-events-none"></div>
             {/* Added leading-tight and py-2 to prevent clipping of descenders/ascenders/shadows */}
             <h1 className="relative text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-br from-pink-400 via-yellow-300 to-cyan-400 drop-shadow-[0_4px_4px_rgba(0,0,0,0.5)] py-4 leading-normal">
               Ruang<br/>Pintar<br/>Ajaib
             </h1>
          </div>
          
          <div className="flex gap-4 text-4xl py-2">
             <span className="animate-bounce" style={{animationDelay: '0s'}}>🦁</span>
             <span className="animate-bounce" style={{animationDelay: '0.2s'}}>🦄</span>
             <span className="animate-bounce" style={{animationDelay: '0.4s'}}>🤖</span>
          </div>

          <p className="text-indigo-200 text-lg font-medium px-4">
            Belajar, Bermain, dan Berpetualang!
          </p>

          <Button onClick={enterApp} variant="primary" className="w-full text-xl py-4 shadow-xl shadow-cyan-500/30 group mt-2">
             <span className="flex items-center gap-3">
                <Play className="fill-current" /> Mulai Petualangan
             </span>
          </Button>
        </GlassCard>
      </div>
    );
  };

  const renderMenu = () => {
    const getStars = (cat: string) => {
       const score = userProgress.categoryScores[cat] || 0;
       return score >= 30 ? 3 : score >= 10 ? 2 : score > 0 ? 1 : 0;
    };

    return (
      <div className="flex flex-col items-center min-h-screen p-4 max-w-md mx-auto space-y-6 pb-12 pt-10">
        <div className="flex justify-between w-full items-center">
          <h1 className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-pink-500 via-yellow-400 to-cyan-500 drop-shadow-md py-1">
            Menu Utama
          </h1>
          <button onClick={toggleMusic} className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-all border border-white/10">
            {isMusicOn ? <Music2 className="text-pink-400" /> : <Music className="text-slate-500" />}
          </button>
        </div>

        {/* Profile Card */}
        <GlassCard className="w-full bg-indigo-950/50">
          <div className="p-4 flex flex-col gap-4">
             <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                   <div className="text-4xl animate-float-slow bg-white/10 rounded-full p-2 border border-white/20">
                      {userProgress.selectedAvatar}
                   </div>
                   <div>
                      <h3 className="text-white font-bold text-lg">Halo, Teman!</h3>
                      <div className="flex items-center gap-1 text-yellow-400">
                         <Star size={16} fill="currentColor" />
                         <span className="font-bold">{userProgress.totalStars} Bintang</span>
                      </div>
                   </div>
                </div>
             </div>
             
             {/* Avatar Selector */}
             <div>
               <p className="text-xs text-indigo-300 uppercase font-bold mb-2">Pilih Karaktermu:</p>
               <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                 {AVATARS.map((avatar, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleAvatarSelect(avatar)}
                      className={`
                        flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-xl transition-all
                        ${userProgress.selectedAvatar === avatar 
                           ? 'bg-gradient-to-br from-pink-500 to-purple-600 scale-110 shadow-lg ring-2 ring-white' 
                           : 'bg-white/10 hover:bg-white/20'
                        }
                      `}
                    >
                      {avatar}
                    </button>
                 ))}
               </div>
             </div>
          </div>
        </GlassCard>

        <div className="grid grid-cols-1 gap-5 w-full">
           <div className="flex items-center gap-2 px-2 opacity-70">
              <div className="h-px bg-white/20 flex-1"></div>
              <span className="text-xs font-bold uppercase tracking-widest text-white">Main & Belajar</span>
              <div className="h-px bg-white/20 flex-1"></div>
           </div>

           <GlassCard interactive onClick={() => startQuiz('animals')} className="h-24">
            <div className="flex items-center h-full px-5 gap-4">
              <div className="p-3 bg-orange-500 rounded-2xl shadow-lg shadow-orange-500/20 text-white"><Cat size={28} /></div>
              <div className="flex-1">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-white">Dunia Hewan</h2>
                  {renderStars(getStars('animals'))}
                </div>
              </div>
            </div>
          </GlassCard>

          <GlassCard interactive onClick={() => startQuiz('math')} className="h-24">
            <div className="flex items-center h-full px-5 gap-4">
              <div className="p-3 bg-blue-500 rounded-2xl shadow-lg shadow-blue-500/20 text-white"><Gamepad2 size={28} /></div>
              <div className="flex-1">
                 <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-white">Matematika</h2>
                  {renderStars(getStars('math'))}
                </div>
              </div>
            </div>
          </GlassCard>

          <GlassCard interactive onClick={startMemoryGame} className="h-24">
             <div className="flex items-center h-full px-5 gap-4">
              <div className="p-3 bg-purple-500 rounded-2xl shadow-lg shadow-purple-500/20 text-white"><Grid3X3 size={28} /></div>
              <div className="flex-1">
                 <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-white">Tebak Kartu</h2>
                  {renderStars(getStars('memory'))}
                </div>
              </div>
            </div>
          </GlassCard>

          <GlassCard interactive onClick={startScrambleGame} className="h-24">
             <div className="flex items-center h-full px-5 gap-4">
              <div className="p-3 bg-pink-500 rounded-2xl shadow-lg shadow-pink-500/20 text-white"><Type size={28} /></div>
              <div className="flex-1">
                 <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-white">Susun Kata</h2>
                  {renderStars(getStars('scramble'))}
                </div>
              </div>
            </div>
          </GlassCard>

          <GlassCard interactive onClick={startStoryMode} className="h-24">
             <div className="flex items-center h-full px-5 gap-4">
              <div className="p-3 bg-emerald-500 rounded-2xl shadow-lg shadow-emerald-500/20 text-white"><BookOpen size={28} /></div>
              <div className="flex-1">
                 <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-xl font-bold text-white">Dongeng Ajaib</h2>
                    <p className="text-xs text-emerald-200">Cerita spesial untukmu</p>
                  </div>
                  <Sparkles className="text-yellow-300 animate-pulse" />
                </div>
              </div>
            </div>
          </GlassCard>
        </div>
      </div>
    );
  };

  const renderStoryMode = () => {
    return (
      <div className="flex flex-col min-h-screen p-4 max-w-lg mx-auto pb-24">
        <div className="flex justify-between items-center mb-6 pt-4">
          <button onClick={resetGame} className="p-3 rounded-full bg-slate-800 text-white border border-white/10 hover:bg-slate-700"><Home size={20} /></button>
          <h2 className="text-xl font-bold text-white">Dongeng {userProgress.selectedAvatar}</h2>
          <div className="w-10"></div>
        </div>

        <GlassCard className="flex-1 flex flex-col items-center justify-center p-6 text-center min-h-[400px]">
          {isThinking ? (
            <div className="flex flex-col items-center gap-4">
               <div className="text-6xl animate-bounce">{userProgress.selectedAvatar}</div>
               <p className="text-indigo-200 animate-pulse">Sedang menulis cerita ajaib...</p>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-6">
              <div className="text-8xl animate-float-slow filter drop-shadow-xl">{userProgress.selectedAvatar}</div>
              <div className="bg-slate-900/40 p-6 rounded-2xl border border-white/5">
                 <p className="text-lg leading-relaxed text-indigo-50 font-medium">
                   {storyText}
                 </p>
              </div>
              <div className="flex gap-4">
                <Button onClick={() => storyText && speakText(storyText)} variant="secondary" className="rounded-full">
                   <Volume2 className={isSpeaking ? 'animate-pulse text-pink-400' : ''} /> Baca Ulang
                </Button>
                <Button onClick={startStoryMode} variant="primary" className="rounded-full">
                   Cerita Baru ✨
                </Button>
              </div>
            </div>
          )}
        </GlassCard>
      </div>
    );
  };

  const renderScrambleGame = () => {
    const q = gameState.scrambleQuestions[gameState.currentQuestionIndex];
    return (
      <div className="flex flex-col min-h-screen p-4 max-w-lg mx-auto pb-24">
        <div className="flex justify-between items-center mb-6 pt-4">
          <button onClick={resetGame} className="p-3 rounded-full bg-slate-800 hover:bg-slate-700 text-white transition-colors border border-white/10">
            <Home size={20} />
          </button>
          <div className="bg-yellow-500/20 px-4 py-1.5 rounded-full border border-yellow-500/50 flex items-center gap-2 backdrop-blur-sm">
            <Trophy size={16} className="text-yellow-400" />
            <span className="font-bold text-yellow-100">{gameState.score}</span>
          </div>
        </div>

        <GlassCard className="mb-8">
           <div className="p-4 flex flex-col items-center">
             <div className="w-full aspect-video rounded-xl overflow-hidden mb-4 border border-white/10 shadow-inner flex items-center justify-center relative bg-slate-900/50">
               <AdaptiveImage src={q.image} alt="Guess" className="w-full h-full" />
               
               <button 
                  onClick={() => speakText(`Susun kata: ${q.hint}`)}
                  className={`absolute bottom-2 right-2 p-2 rounded-full bg-white/20 backdrop-blur text-white hover:bg-white/30 transition-all ${isSpeaking ? 'scale-110 ring-2 ring-white/50' : ''}`}
               >
                  <Volume2 size={20} className={isSpeaking ? 'animate-pulse' : ''} />
               </button>
             </div>
             <p className="text-indigo-200 text-sm animate-pulse text-center">{q.hint}</p>
           </div>
        </GlassCard>

        {/* Answer Slots */}
        <div className="flex justify-center gap-2 mb-8 flex-wrap">
           {gameState.placedLetters.map((slot, i) => (
              <div 
                key={i} 
                onClick={() => handleSlotClick(i)}
                className={`
                  w-14 h-14 rounded-xl flex items-center justify-center text-2xl font-bold border-2 transition-all
                  ${slot.char 
                     ? 'bg-gradient-to-br from-indigo-500 to-purple-600 border-indigo-400 text-white shadow-lg cursor-pointer transform hover:scale-105' 
                     : 'bg-slate-800/50 border-white/10 text-white/5'
                  }
                `}
              >
                 {slot.char}
              </div>
           ))}
        </div>

        {/* Letter Pool */}
        <div className="grid grid-cols-5 gap-2 px-2">
           {gameState.currentScrambleLetters.map((letter) => (
              <button
                 key={letter.id}
                 onClick={() => handleLetterClick(letter.id)}
                 disabled={letter.status === 'placed'}
                 className={`
                    aspect-square rounded-xl font-bold text-xl flex items-center justify-center transition-all duration-300
                    ${letter.status === 'placed' 
                       ? 'bg-slate-800/20 text-transparent opacity-0 scale-50' 
                       : 'bg-white text-slate-900 shadow-[0_4px_0_rgb(203,213,225)] active:translate-y-[4px] active:shadow-none hover:bg-slate-100'
                    }
                 `}
              >
                 {letter.char}
              </button>
           ))}
        </div>

        {/* AI Hint Button */}
        <div className="fixed bottom-6 left-0 right-0 px-4 flex justify-center z-50">
             <button
               onClick={handleGetHelp}
               className="flex items-center gap-2 px-6 py-3 rounded-full bg-slate-800 border border-white/20 text-white text-sm font-bold shadow-xl backdrop-blur-md active:scale-95 transition-transform"
             >
               <Bot size={18} className="text-pink-400" />
               {aiHint ? aiHint : 'Butuh Bantuan?'}
             </button>
        </div>
      </div>
    );
  };

  const renderGameContent = () => {
    if (gameState.mode === 'memory') {
       return (
        <div className="flex flex-col min-h-screen p-4 max-w-lg mx-auto pb-8">
          <div className="flex justify-between items-center mb-6 pt-4">
            <button onClick={resetGame} className="p-3 rounded-full bg-slate-800 text-white border border-white/10"><Home size={20} /></button>
            <h2 className="text-xl font-bold text-white">Tebak Kartu</h2>
            <div className="bg-yellow-500/20 px-3 py-1 rounded-full border border-yellow-500/30 flex items-center gap-1">
              <Trophy size={16} className="text-yellow-400" /><span className="font-bold text-yellow-100">{gameState.score}</span>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3 w-full aspect-[3/4]">
            {gameState.memoryCards.map((card, idx) => (
              <div key={card.id + idx} className="relative h-28 perspective-1000 cursor-pointer" onClick={() => handleCardClick(idx)}>
                 <div className={`w-full h-full transition-all duration-500 transform-style-3d ${card.isFlipped || card.isMatched ? 'rotate-y-180' : ''}`}>
                   <div className="absolute inset-0 w-full h-full backface-hidden">
                      <GlassCard className="h-full flex items-center justify-center bg-indigo-900/40"><Bot className="text-white/20" size={32} /></GlassCard>
                   </div>
                   <div className="absolute inset-0 w-full h-full backface-hidden rotate-y-180">
                     <GlassCard className={`h-full flex items-center justify-center ${card.isMatched ? 'bg-green-500/30 ring-2 ring-green-400' : 'bg-slate-800'}`}>
                        <span className="text-4xl drop-shadow-md">{card.content}</span>
                     </GlassCard>
                   </div>
                 </div>
              </div>
            ))}
          </div>
        </div>
       );
    }
    
    // Quiz Mode
    const question = gameState.questions[gameState.currentQuestionIndex];
    return (
      <div className="flex flex-col min-h-screen p-4 max-w-lg mx-auto pb-24">
        <div className="flex justify-between items-center mb-6 pt-4">
          <button onClick={resetGame} className="p-3 rounded-full bg-slate-800 text-white border border-white/10"><Home size={20} /></button>
          <div className="bg-yellow-500/20 px-3 py-1 rounded-full border border-yellow-500/30 flex items-center gap-1">
            <Trophy size={16} className="text-yellow-400" /><span className="font-bold text-yellow-100">{gameState.score}</span>
          </div>
        </div>
        
        <GlassCard className="mb-6">
          <div className="p-4 flex flex-col items-center">
            <div className="w-full h-48 rounded-xl overflow-hidden mb-4 border border-white/10 bg-black/20 relative">
               <AdaptiveImage src={question.image} alt="Question Image" />
            </div>
            <div className="flex items-start gap-3 w-full">
              <h2 className="text-xl font-bold text-left text-white flex-1">{question.question}</h2>
              <button 
                 onClick={() => speakText(question.question)}
                 className={`p-2 rounded-full bg-indigo-500/20 text-indigo-300 hover:bg-indigo-500/40 transition-all shrink-0 ${isSpeaking ? 'animate-pulse text-indigo-100 bg-indigo-500/50' : ''}`}
              >
                <Volume2 size={24} />
              </button>
            </div>
          </div>
        </GlassCard>

        {aiHint && (
          <div className="mb-6 animate-pulse">
             <div className="bg-indigo-600/30 border border-indigo-400/50 rounded-xl p-3 flex items-start gap-3">
                <Bot className="shrink-0 text-indigo-300" size={20} />
                <p className="text-indigo-100 text-sm italic">{aiHint}</p>
             </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          {question.options.map((option, idx) => {
            const isSelected = selectedAnswer === option;
            const isCorrectAnswer = option === question.correctAnswer;
            let variant: 'secondary' | 'success' | 'danger' = 'secondary';
            
            if (isSelected) variant = isCorrect ? 'success' : 'danger';
            else if (selectedAnswer && isCorrectAnswer) variant = 'success';

            return (
              <Button key={idx} variant={variant} onClick={() => handleQuizAnswer(option)} className="h-16 text-lg" disabled={!!selectedAnswer}>
                {option}
                {isSelected && (
                   <span className="absolute right-2 top-2">{isCorrect ? <CheckCircle size={18} /> : <XCircle size={18} />}</span>
                )}
              </Button>
            );
          })}
        </div>

        {!selectedAnswer && (
          <div className="fixed bottom-6 left-0 right-0 px-4 flex justify-center z-50">
             <button onClick={handleGetHelp} disabled={isThinking} className="flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-violet-600 to-indigo-600 text-white font-bold shadow-lg shadow-indigo-500/50 transition-all transform active:scale-95 border border-white/20">
               <Bot size={24} className={isThinking ? 'animate-spin' : ''} />
               {isThinking ? '...' : 'Tanya Teman Ajaib'}
             </button>
          </div>
        )}
      </div>
    );
  };

  const renderResult = () => {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-6 text-center max-w-md mx-auto">
        <GlassCard className="p-8 w-full flex flex-col items-center gap-6">
          <div className="relative">
            <div className="absolute inset-0 bg-yellow-500 blur-2xl opacity-40 animate-pulse"></div>
            <Trophy size={100} className="text-yellow-400 relative z-10 drop-shadow-xl" />
          </div>
          <div>
            <h2 className="text-4xl font-black text-white mb-2">Hore! 🎉</h2>
            <p className="text-blue-200">Kamu hebat sekali!</p>
          </div>
          <div className="bg-slate-900/60 p-6 rounded-2xl border border-white/10 w-full backdrop-blur-sm">
            <span className="text-slate-400 text-xs uppercase tracking-widest font-bold">Total Skor</span>
            <div className="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-500 mt-2 filter drop-shadow-lg">
              {gameState.score}
            </div>
            <div className="mt-4 flex justify-center gap-2">
               {[...Array(3)].map((_, i) => (
                  <Star key={i} size={28} className={`${i < Math.floor(gameState.score / 20) ? 'fill-yellow-400 text-yellow-400 animate-bounce' : 'text-slate-700'}`} style={{ animationDelay: `${i * 150}ms` }} />
               ))}
            </div>
          </div>
          <Button onClick={resetGame} variant="primary" className="w-full py-4 mt-2 text-xl">
            <RotateCcw size={24} /> Main Lagi
          </Button>
        </GlassCard>
      </div>
    );
  };

  return (
    <div className="min-h-screen font-fredoka bg-slate-950 relative overflow-hidden text-slate-100">
      {/* Animated Background */}
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none z-0 opacity-40">
         <div className="absolute top-[10%] left-[10%] w-96 h-96 bg-purple-600/30 rounded-full blur-[100px] animate-pulse"></div>
         <div className="absolute bottom-[20%] right-[10%] w-80 h-80 bg-blue-600/30 rounded-full blur-[100px] animate-pulse delay-700"></div>
         <div className="absolute top-[40%] left-[40%] w-64 h-64 bg-pink-600/20 rounded-full blur-[80px] animate-float"></div>
      </div>

      <div className="relative z-10">
        {gameState.screen === 'landing' && renderLanding()}
        {gameState.screen === 'menu' && renderMenu()}
        {gameState.screen === 'playing' && (
           gameState.mode === 'scramble' ? renderScrambleGame() : 
           gameState.mode === 'story' ? renderStoryMode() :
           renderGameContent()
        )}
        {gameState.screen === 'result' && renderResult()}
      </div>

      {showConfetti && (
        <div className="fixed inset-0 pointer-events-none z-[100] flex items-center justify-center">
            <div className="absolute inset-0 bg-black/20 backdrop-blur-[2px]"></div>
            <h1 className="text-8xl animate-bounce drop-shadow-2xl">🎉</h1>
        </div>
      )}
    </div>
  );
};

export default App;
