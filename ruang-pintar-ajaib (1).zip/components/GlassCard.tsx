import React from 'react';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  interactive?: boolean;
}

export const GlassCard: React.FC<GlassCardProps> = ({ 
  children, 
  className = "", 
  onClick,
  interactive = false
}) => {
  return (
    <div 
      className={`relative group z-0 ${className} ${interactive ? 'cursor-pointer' : ''}`}
      onClick={onClick}
    >
      {/* 
         RAINBOW BORDER LAYER 
         This uses a conic-gradient that spins.
         We place it behind the content.
         The 'inset-[-3px]' creates the border thickness visible around the content.
      */}
      <div 
        className="
          absolute inset-[-3px] 
          rounded-2xl 
          bg-[conic-gradient(from_var(--angle),#ef4444,#f97316,#eab308,#22c55e,#3b82f6,#6366f1,#a855f7,#ef4444)]
          animate-spin-border
          opacity-70
          blur-[2px]
          transition-all duration-300
        "
        style={{
          // @ts-ignore - Custom property
          '--angle': '0deg'
        }}
      ></div>

      {/* OUTER GLOW LAYER (Softer, wider blur) */}
      <div 
        className={`
          absolute inset-[-4px] 
          rounded-2xl 
          bg-[conic-gradient(from_var(--angle),#ef4444,#f97316,#eab308,#22c55e,#3b82f6,#6366f1,#a855f7,#ef4444)]
          animate-spin-border
          opacity-40
          blur-md
          transition-all duration-500
          ${interactive ? 'group-hover:opacity-80 group-hover:blur-xl group-hover:inset-[-6px]' : ''}
        `}
         style={{
          // @ts-ignore
          '--angle': '180deg' // Offset for richer color mixing
        }}
      ></div>

      {/* 
         CONTENT BACKGROUND 
         Dark slate background to cover the center of the gradient,
         creating the "border" effect.
      */}
      <div className="relative h-full bg-slate-950/90 backdrop-blur-md rounded-2xl overflow-hidden flex flex-col z-10 border border-white/5">
        
        {/* Subtle internal shimmer */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-50 pointer-events-none"></div>

        {/* Content */}
        <div className="relative z-20 h-full w-full">
          {children}
        </div>
      </div>
    </div>
  );
};