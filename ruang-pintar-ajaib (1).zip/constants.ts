import { Question, ScrambleQuestion } from './types';

// Avatars for the profile
export const AVATARS = [
  "🦁", "🦄", "🤖", "👽", "🦊", "🐸", "🐼", "🐯"
];

// Updated images to be more reliable/cartoony
export const SAMPLE_QUESTIONS: Record<string, Question[]> = {
  animals: [
    {
      id: 1,
      question: "Hewan apakah ini yang memiliki leher sangat panjang?",
      image: "https://images.unsplash.com/photo-1547721064-da6cfb341d50?auto=format&fit=crop&w=800&q=80", 
      options: ["Gajah", "Jerapah", "Kuda", "Singa"],
      correctAnswer: "Jerapah",
      category: "animals"
    },
    {
      id: 2,
      question: "Raja hutan yang memiliki surai (rambut lebat) di kepalanya adalah...",
      image: "https://images.unsplash.com/photo-1614027164847-1b28cfe1df60?auto=format&fit=crop&w=800&q=80", 
      options: ["Harimau", "Kucing", "Singa", "Beruang"],
      correctAnswer: "Singa",
      category: "animals"
    },
    {
      id: 3,
      question: "Hewan ini suka makan pisang dan pandai memanjat pohon.",
      image: "https://images.unsplash.com/photo-1540573133985-87b6da6d54a9?auto=format&fit=crop&w=800&q=80", 
      options: ["Monyet", "Ayam", "Sapi", "Ikan"],
      correctAnswer: "Monyet",
      category: "animals"
    }
  ],
  math: [
    {
      id: 4,
      question: "Ada 3 apel ditambah 2 apel. Berapa jumlah semua apel?",
      image: "https://images.unsplash.com/photo-1610832958506-aa56368176cf?auto=format&fit=crop&w=800&q=80", // Fruit
      options: ["4", "5", "6", "10"],
      correctAnswer: "5",
      category: "math"
    },
    {
      id: 5,
      question: "Bentuk bangun datar apakah ini?",
      image: "https://images.unsplash.com/photo-1599596398939-50280425a7f5?auto=format&fit=crop&w=800&q=80", // Colorful triangles/shapes
      options: ["Lingkaran", "Segitiga", "Kotak", "Bintang"],
      correctAnswer: "Segitiga",
      category: "math"
    },
    {
      id: 6,
      question: "10 dikurang 3 sama dengan...",
      image: "https://images.unsplash.com/photo-1518133910546-b6c2fb7d79e3?auto=format&fit=crop&w=800&q=80", 
      options: ["7", "8", "6", "5"],
      correctAnswer: "7",
      category: "math"
    }
  ],
  science: [
    {
      id: 7,
      question: "Planet tempat kita tinggal bernama...",
      image: "https://images.unsplash.com/photo-1614730341194-75c6074065db?auto=format&fit=crop&w=800&q=80", // Earth
      options: ["Mars", "Bumi", "Bulan", "Matahari"],
      correctAnswer: "Bumi",
      category: "science"
    },
    {
      id: 8,
      question: "Benda langit yang bersinar panas di siang hari adalah...",
      image: "https://images.unsplash.com/photo-1533983202919-6c3709280152?auto=format&fit=crop&w=800&q=80", 
      options: ["Bulan", "Bintang", "Matahari", "Awan"],
      correctAnswer: "Matahari",
      category: "science"
    },
    {
      id: 9,
      question: "Air yang turun dari langit disebut...",
      image: "https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?auto=format&fit=crop&w=800&q=80", 
      options: ["Salju", "Hujan", "Angin", "Petir"],
      correctAnswer: "Hujan",
      category: "science"
    }
  ]
};

export const SCRAMBLE_QUESTIONS: ScrambleQuestion[] = [
  {
    id: 1,
    word: "BUKU",
    image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=800&q=80", // Open book
    hint: "Benda untuk dibaca"
  },
  {
    id: 2,
    word: "BOLA",
    image: "https://images.unsplash.com/photo-1614632537423-1e6c2e7e0aab?auto=format&fit=crop&w=800&q=80", // Soccer ball
    hint: "Benda bulat untuk main sepak bola"
  },
  {
    id: 3,
    word: "ROTI",
    image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80", // Bread
    hint: "Makanan enak untuk sarapan"
  },
  {
    id: 4,
    word: "MEJA",
    image: "https://images.unsplash.com/photo-1595514693442-f87c93275752?auto=format&fit=crop&w=800&q=80", // Clear white table
    hint: "Tempat menaruh makanan"
  },
  {
    id: 5,
    word: "IKAN",
    image: "https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?auto=format&fit=crop&w=800&q=80",
    hint: "Hewan yang berenang di air"
  }
];

// Memory Game Emojis
export const MEMORY_EMOJIS = [
  "🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼"
];