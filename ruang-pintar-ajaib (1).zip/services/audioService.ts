
// Simple Web Audio API Synthesizer for Game SFX & BGM
// No external assets required

let audioCtx: AudioContext | null = null;
let bgmInterval: number | null = null;
let bgmNoteIndex = 0;
let isMuted = false;

const getContext = () => {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  return audioCtx;
};

// Helper to play multiple tones at once (chords)
const playTone = (
  freq: number, 
  type: OscillatorType, 
  duration: number, 
  startTime: number = 0,
  vol: number = 0.5
) => {
  if (isMuted) return;
  
  const ctx = getContext();
  if (ctx.state === 'suspended') {
    ctx.resume();
  }

  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = type;
  osc.frequency.setValueAtTime(freq, ctx.currentTime + startTime);
  
  gain.gain.setValueAtTime(0, ctx.currentTime + startTime);
  gain.gain.linearRampToValueAtTime(vol, ctx.currentTime + startTime + 0.05);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + startTime + duration);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(ctx.currentTime + startTime);
  osc.stop(ctx.currentTime + startTime + duration);
};

export const toggleMute = (muted: boolean) => {
  isMuted = muted;
  if (isMuted) stopBGM();
  else startBGM();
};

// --- BGM Logic ---
// Simple pentatonic C major loop: C E G A G E
const MELODY = [261.63, 329.63, 392.00, 440.00, 392.00, 329.63]; 
// Harmony lines
const BASS = [130.81, 164.81, 196.00];

export const startBGM = () => {
  if (bgmInterval || isMuted) return;
  
  const ctx = getContext();
  // Ensure context is running (browser policy requires interaction)
  if (ctx.state === 'suspended') ctx.resume();

  bgmNoteIndex = 0;
  
  // Play a note every 600ms
  bgmInterval = window.setInterval(() => {
    if (isMuted) return;

    // Melody - Sine wave (soft)
    const note = MELODY[bgmNoteIndex % MELODY.length];
    playTone(note, 'sine', 0.8, 0, 0.05); // Very low volume for background

    // Bass - every 3rd beat
    if (bgmNoteIndex % 3 === 0) {
      const bassNote = BASS[(bgmNoteIndex / 3) % BASS.length];
      playTone(bassNote, 'triangle', 1.5, 0, 0.03);
    }

    bgmNoteIndex++;
  }, 600);
};

export const stopBGM = () => {
  if (bgmInterval) {
    clearInterval(bgmInterval);
    bgmInterval = null;
  }
};

// --- SFX Logic ---

export const playClick = () => {
  playTone(600, 'sine', 0.1, 0, 0.4);
  playTone(800, 'sine', 0.05, 0.05, 0.2);
};

export const playPop = () => {
  playTone(400, 'sine', 0.05, 0, 0.5);
  playTone(600, 'sine', 0.05, 0.02, 0.3);
};

export const playFlip = () => {
  playTone(300, 'triangle', 0.1, 0, 0.4);
  playTone(500, 'triangle', 0.1, 0.02, 0.2);
};

export const playCorrect = () => {
  const now = 0;
  playTone(523.25, 'sine', 0.3, now, 0.5);      // C5
  playTone(659.25, 'sine', 0.3, now + 0.05, 0.5);    // E5
  playTone(783.99, 'sine', 0.5, now + 0.1, 0.5);    // G5
  playTone(1046.50, 'square', 0.2, now + 0.1, 0.1);      // C6 sparkle
};

export const playWrong = () => {
  playTone(150, 'sawtooth', 0.4, 0, 0.4);
  playTone(100, 'sawtooth', 0.4, 0.05, 0.4);
};

export const playWin = () => {
  const now = 0;
  const vol = 0.4;
  playTone(523.25, 'square', 0.15, now, vol);
  playTone(523.25, 'square', 0.15, now + 0.15, vol);
  playTone(523.25, 'square', 0.15, now + 0.3, vol);
  playTone(659.25, 'square', 0.4, now + 0.45, vol);
  playTone(783.99, 'square', 0.6, now + 0.85, vol);
  // Harmony
  playTone(329.63, 'sine', 0.6, now + 0.45, vol); // E4
  playTone(392.00, 'sine', 0.8, now + 0.85, vol); // G4
};
