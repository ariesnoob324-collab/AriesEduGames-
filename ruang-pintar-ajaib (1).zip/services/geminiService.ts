import { GoogleGenAI } from "@google/genai";

// Initialize the Gemini client
// Per guidelines, we must use process.env.API_KEY
const apiKey = process.env.API_KEY || '';

// Fallback logic to prevent crash if key is missing (shows warning in console)
if (!apiKey) {
  console.warn("API Key Google Gemini belum diset! Pastikan setting API_KEY di environment variables.");
}

const ai = new GoogleGenAI({ apiKey: apiKey });

export const getGeminiHelp = async (question: string, options: string[]): Promise<string> => {
  if (!apiKey) return "Maaf, kunci ajaibku ketinggalan (API Key Missing).";

  try {
    const model = 'gemini-2.5-flash';
    const prompt = `
      Kamu adalah teman belajar yang ceria dan seru untuk anak-anak Indonesia (usia 6-10 tahun).
      
      Pertanyaan saat ini: "${question}"
      Pilihan jawaban: ${options.join(', ')}

      Tugasmu:
      Berikan petunjuk (hint) singkat yang sangat mudah dimengerti anak kecil untuk membantu mereka menemukan jawaban yang benar.
      JANGAN langsung memberitahu jawabannya.
      Gunakan Bahasa Indonesia yang gaul tapi sopan untuk anak-anak.
      Gunakan emoji yang lucu.
      Maksimal 2 kalimat.
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        temperature: 0.7,
      }
    });

    return response.text || "Wah, sepertinya aku sedang berpikir keras. Coba lagi ya!";
  } catch (error) {
    console.error("Error getting help from Gemini:", error);
    return "Maaf ya, koneksiku sedang gangguan. Semangat terus!";
  }
};

export const getAvatarStory = async (avatar: string): Promise<string> => {
  if (!apiKey) return "Belum bisa cerita nih, kunci ajaibnya belum ada.";

  try {
    const model = 'gemini-2.5-flash';
    // Map emoji to character name
    const charName = avatar === "🦁" ? "Singa Pemberani" :
                     avatar === "🦄" ? "Kuda Poni Ajaib" :
                     avatar === "🤖" ? "Robot Pintar" :
                     avatar === "👽" ? "Alien Ramah" :
                     avatar === "🦊" ? "Rubah Cerdik" :
                     avatar === "🐸" ? "Katak Lompat" :
                     avatar === "🐼" ? "Panda Lucu" :
                     "Harimau Kuat";

    const prompt = `
      Buatlah cerita SANGAT PENDEK (maksimal 3 kalimat) tentang karakter ${charName} (${avatar}).
      Ceritanya harus tentang kebaikan, persahabatan, atau belajar hal baru.
      Gunakan bahasa Indonesia yang sederhana dan ceria untuk anak TK/SD.
      Jangan gunakan formatting bold/italic.
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        temperature: 0.8,
      }
    });

    return response.text || `Suatu hari, ${charName} sedang bermain dengan gembira di taman bunga.`;
  } catch (error) {
    return "Maaf, aku belum bisa bercerita sekarang. Coba lagi nanti ya!";
  }
};